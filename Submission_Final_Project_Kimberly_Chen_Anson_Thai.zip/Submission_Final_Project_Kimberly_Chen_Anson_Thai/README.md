# Instructions

## Install Requirements
pip install -r requirements.txt

## Run the Program
cd Code

Usage:
python colorize.py <gray_filename> <scribble_filename> <result_filename>
(ensure each image file is in the correct directory)

Example:
python colorize.py gray1.png scribble1.png result1.png